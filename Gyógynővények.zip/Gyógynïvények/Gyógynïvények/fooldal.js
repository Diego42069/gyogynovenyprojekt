let fe = document.getElementById("fe")
let le = document.getElementById("le")
let kasv = document.getElementById("kas")
let fekete = document.getElementById("feketeurom")
let lev = document.getElementById("levendula")
let kas = document.getElementById("kasvirag")

kas.onmouseover = function(){
    kasv.style.opacity = 1
}
kas.onmouseleave = function(){
    kasv.style.opacity = 0
}
fekete.onmouseover = function(){
    fe.style.opacity = 1
}
fekete.onmouseleave = function(){
    fe.style.opacity = 0
}
lev.onmouseover = function(){
    le.style.opacity = 1
}
lev.onmouseleave = function(){
    le.style.opacity = 0
}